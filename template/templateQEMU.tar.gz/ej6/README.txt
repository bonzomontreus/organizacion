aarch64-linux-gnu-gcc main.c -O1 -S -o- -xc
